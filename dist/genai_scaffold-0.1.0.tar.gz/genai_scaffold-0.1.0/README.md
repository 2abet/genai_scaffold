# genai_scaffold

Generate structured generative AI project templates easily.
